export type Role = 'landing' | 'teacher' | 'student' | 'admin';
export type UILanguage = 'en' | 'hi';

export interface Chapter {
  id: string;
  title: string;
  subject: string;
  grade: string;
  language: string;
  created_at: string;
  sections?: Section[];
}

export interface Section {
  id: string;
  chapter_id: string;
  section_number: number;
  title: string;
  content: string;
}

export interface GroundedDoubtResponse {
  success: boolean;
  doubtId?: string;
  in_chapter: boolean;
  answer: string;
  section: string | null;
  quote: string | null;
  verified: boolean;
  ghar_ki_boli?: string;
  bilingual_en?: string;
}

export interface DoubtItem {
  id: string;
  student_id: string;
  student_name: string;
  chapter_id: string;
  section_ref: string | null;
  question: string;
  answer: string;
  in_chapter: number;
  quote: string | null;
  verified: number;
  asked_at: string;
  forwarded_to_teacher: number;
  teacher_reply: string | null;
}

export interface QuizQuestion {
  q: string;
  options: string[];
  answer: string;
  section: string;
  evidence: string;
  verified: boolean;
  teacher_check_required?: boolean;
}

export interface LessonPlanOutput {
  class: string;
  subject: string;
  chapter: string;
  period_length_minutes: number;
  language: string;
  objectives: string[];
  materials_needed: string[];
  board_diagram_description: string;
  timed_flow: {
    step: string;
    duration_minutes: number;
    section_ref: string;
    teacher_activity: string;
    student_activity: string;
  }[];
  quiz_questions: QuizQuestion[];
}

export interface TopicStat {
  topic: string;
  displayName: string;
  totalQuestions: number;
  totalCorrect: number;
  classMean: number;
  below40Count: number;
}

export interface StudentPerformance {
  student_id: string;
  name: string;
  gender: string;
  class: string;
  section: string;
  preferred_language: string;
  overallAvg: number;
  weakestTopicScore: number;
  weakestTopicName: string;
}

export interface RemedialGroupTier {
  title: string;
  count: number;
  students: StudentPerformance[];
  activity10Min: string;
}

export interface DashboardStats {
  weakestTopic: TopicStat;
  topicStats: TopicStat[];
  studentsWhoNeedHelp: StudentPerformance[];
  totalStudents: number;
  remedialGroups: {
    needsHelp: RemedialGroupTier;
    onTrack: RemedialGroupTier;
    readyToStretch: RemedialGroupTier;
  };
  doubtHotspots: { section_ref: string; count: number }[];
}

export interface ParentReport {
  student_id: string;
  name: string;
  class: string;
  section: string;
  preferred_language: string;
  overallAvg: number;
  saproScore: number;
  needsHelp: boolean;
  approved: boolean;
  message: string;
  whatsappText: string;
  whatsappUrl: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'alert' | 'warning' | 'info' | 'question' | 'success';
  read: number;
  created_at: string;
}

export interface AcceptanceTestItem {
  test_id: number;
  title: string;
  description: string;
  passed: boolean;
  details: any;
}
