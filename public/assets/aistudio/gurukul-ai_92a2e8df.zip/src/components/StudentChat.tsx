import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Send,
  Volume2,
  VolumeX,
  Sparkles,
  BookOpen,
  ArrowRight,
  HelpCircle,
  CheckCircle2,
  AlertCircle,
  Inbox,
  Languages,
  Home,
  MessageSquare
} from 'lucide-react';
import { Chapter, UILanguage, GroundedDoubtResponse } from '../types';

interface StudentChatProps {
  chapters: Chapter[];
  selectedChapterId: string;
  onSelectChapter: (id: string) => void;
  uiLang: UILanguage;
}

interface ChatMessage {
  id: string;
  sender: 'student' | 'assistant';
  text: string;
  responseObj?: GroundedDoubtResponse;
  timestamp: string;
}

export const StudentChat: React.FC<StudentChatProps> = ({
  chapters,
  selectedChapterId,
  onSelectChapter,
  uiLang,
}) => {
  const [studentId, setStudentId] = useState('S001'); // Ravi Gupta
  const [studentName, setStudentName] = useState('Ravi Gupta');
  const [roster, setRoster] = useState<{ student_id: string; name: string; preferred_language: string }[]>([]);
  const [inputQuestion, setInputQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  
  // Toggles requested in prompt
  const [showGharKiBoli, setShowGharKiBoli] = useState(false);
  const [showBilingual, setShowBilingual] = useState(false);
  const [forwardSuccessId, setForwardSuccessId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Initial welcome message
    const welcomeText = uiLang === 'hi'
      ? 'नमस्ते! मैं गुरुकुल AI हूँ। अपने पाठ से कोई भी सवाल पूछें—बोलकर या लिखकर। मैं केवल आपकी किताब से उत्तर दूँगा।'
      : 'Namaste! I am Gurukul AI. Ask any question from your chapter by speaking or typing. I will only answer from your textbook.';

    setMessages([
      {
        id: 'msg_welcome',
        sender: 'assistant',
        text: welcomeText,
        timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      },
    ]);

    // Setup Web Speech Recognition for Hindi (hi-IN)
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'hi-IN';

        recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setInputQuestion(transcript);
          setIsListening(false);
        };

        recognition.onerror = () => {
          setIsListening(false);
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = recognition;
      }
    }

    // Fetch roster students for student profile picker
    fetch('/api/students')
      .then(res => res.json())
      .then(data => {
        if (data.students && data.students.length > 0) {
          setRoster(data.students);
        }
      })
      .catch(() => {});
  }, [uiLang]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const toggleVoiceInput = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in this browser. Please type your doubt.');
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setIsListening(true);
      recognitionRef.current.start();
    }
  };

  const speakText = (text: string, msgId: string) => {
    if (!('speechSynthesis' in window)) return;

    if (speakingMsgId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    // Prefer Hindi voice if available
    const voices = window.speechSynthesis.getVoices();
    const hiVoice = voices.find(v => v.lang.includes('hi') || v.lang.includes('IN'));
    if (hiVoice) utterance.voice = hiVoice;
    utterance.rate = 0.95;

    utterance.onend = () => setSpeakingMsgId(null);
    utterance.onerror = () => setSpeakingMsgId(null);

    setSpeakingMsgId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  const handleSend = async (qText?: string) => {
    const questionToSend = qText || inputQuestion.trim();
    if (!questionToSend || loading) return;

    const userMsgId = `usr_${Date.now()}`;
    const userMsg: ChatMessage = {
      id: userMsgId,
      sender: 'student',
      text: questionToSend,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuestion('');
    setLoading(true);

    try {
      const res = await fetch('/api/doubt/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: questionToSend,
          chapterId: selectedChapterId,
          studentId,
          studentName,
          preferredLanguage: uiLang === 'hi' ? 'hindi' : 'hinglish',
        }),
      });

      const data: GroundedDoubtResponse = await res.json();
      const botMsgId = `bot_${Date.now()}`;

      const botMsg: ChatMessage = {
        id: botMsgId,
        sender: 'assistant',
        text: data.answer,
        responseObj: data,
        timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages(prev => [...prev, botMsg]);
    } catch (e: any) {
      setMessages(prev => [
        ...prev,
        {
          id: `bot_err_${Date.now()}`,
          sender: 'assistant',
          text: 'नेटवर्क समस्या हुई। कृपया पुनः प्रयास करें। (Connection error, please retry.)',
          timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const forwardToTeacher = async (doubtId?: string, questionText?: string) => {
    try {
      await fetch('/api/doubt/forward-to-teacher', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          doubtId,
          question: questionText,
          studentId,
          studentName,
          chapterId: selectedChapterId,
        }),
      });
      if (doubtId) {
        setForwardSuccessId(doubtId);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const starterDoubtChips = [
    { label: 'stomata kya hota hai?', desc: 'Stomata doubt (Acceptance Test 1)' },
    { label: 'मृतजीवी (Saprotrophs) क्या होते हैं?', desc: 'Saprotrophs doubt' },
    { label: 'What is evaporation?', desc: 'Water Cycle dynamic test' },
    { label: 'Who won the cricket match?', desc: 'Off-chapter refusal (Acceptance Test 2)' },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      
      {/* Top Banner: Student Info & Chapter Picker */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 mb-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-500 to-orange-400 flex items-center justify-center text-white font-bold text-sm shadow-sm">
            {studentName.charAt(0)}
          </div>
          <div>
            <div className="flex items-center space-x-2">
              {roster.length > 0 ? (
                <select
                  value={studentId}
                  onChange={e => {
                    const sel = roster.find(s => s.student_id === e.target.value);
                    if (sel) {
                      setStudentId(sel.student_id);
                      setStudentName(sel.name);
                    }
                  }}
                  className="font-bold text-sm text-slate-900 dark:text-white bg-transparent border-b border-dashed border-slate-300 dark:border-slate-700 py-0.5 focus:outline-none focus:border-amber-500 cursor-pointer"
                >
                  {roster.map(st => (
                    <option key={st.student_id} value={st.student_id} className="dark:bg-slate-900 text-slate-900 dark:text-white">
                      {st.name} ({st.student_id})
                    </option>
                  ))}
                </select>
              ) : (
                <span className="font-bold text-sm text-slate-900 dark:text-white">{studentName}</span>
              )}
              <span className="text-xs px-2 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-mono">
                रोल नं: {studentId}
              </span>
              <span className="text-xs px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                कक्षा 7A
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              राजकीय मध्य विद्यालय, दानापुर (पटना) · वर्ग 7A
            </p>
          </div>
        </div>

        {/* Chapter Selection */}
        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <BookOpen className="w-4 h-4 text-amber-600 shrink-0" />
          <select
            value={selectedChapterId}
            onChange={e => onSelectChapter(e.target.value)}
            className="w-full sm:w-64 text-xs font-semibold py-1.5 px-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500"
          >
            {chapters.map(ch => (
              <option key={ch.id} value={ch.id}>
                {ch.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Feature Toggles Bar */}
      <div className="flex items-center justify-between bg-amber-50/80 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40 rounded-xl px-3 py-2 mb-4 text-xs">
        <div className="flex items-center space-x-4">
          <label className="flex items-center space-x-1.5 cursor-pointer text-slate-700 dark:text-slate-300">
            <input
              type="checkbox"
              checked={showGharKiBoli}
              onChange={e => setShowGharKiBoli(e.target.checked)}
              className="rounded text-amber-600 focus:ring-amber-500"
            />
            <span className="flex items-center space-x-1">
              <Home className="w-3.5 h-3.5 text-amber-600" />
              <span className="font-semibold">घर की बोली</span>
              <span className="text-[9px] px-1 py-0.2 rounded bg-amber-200 text-amber-800 dark:bg-amber-900 dark:text-amber-200 font-bold uppercase">
                BETA
              </span>
            </span>
          </label>

          <label className="flex items-center space-x-1.5 cursor-pointer text-slate-700 dark:text-slate-300">
            <input
              type="checkbox"
              checked={showBilingual}
              onChange={e => setShowBilingual(e.target.checked)}
              className="rounded text-amber-600 focus:ring-amber-500"
            />
            <span className="flex items-center space-x-1">
              <Languages className="w-3.5 h-3.5 text-amber-600" />
              <span className="font-semibold">Bilingual (हिंदी + EN)</span>
            </span>
          </label>
        </div>

        <div className="text-[11px] text-amber-800 dark:text-amber-300 font-medium hidden sm:block">
          🛡️ केवल पाठ्यपुस्तक से सत्यापित उत्तर
        </div>
      </div>

      {/* Chat Messages Container */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-4 h-[55vh] overflow-y-auto space-y-4">
        {messages.map(msg => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'student' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm shadow-sm ${
                msg.sender === 'student'
                  ? 'bg-amber-600 text-white rounded-br-none'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-bl-none border border-slate-200 dark:border-slate-700/60'
              }`}
            >
              {/* Message Text */}
              <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>

              {/* If Grounded in Chapter: Show Source Citation & Quote */}
              {msg.responseObj && msg.responseObj.in_chapter && (
                <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700 space-y-2">
                  
                  {/* Source Section Badge */}
                  {msg.responseObj.section && (
                    <div className="flex items-center space-x-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-1 rounded-lg border border-emerald-200 dark:border-emerald-900">
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                      <span>{uiLang === 'hi' ? 'प्रमाणित स्रोत' : 'Verified Section'}: {msg.responseObj.section}</span>
                    </div>
                  )}

                  {/* Quoted Sentence from Textbook */}
                  {msg.responseObj.quote && (
                    <div className="text-xs bg-white dark:bg-slate-900/80 p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 italic">
                      <span className="font-semibold text-slate-500 dark:text-slate-400 not-italic block text-[10px] uppercase">
                        {uiLang === 'hi' ? 'पाठ्यपुस्तक का मूल वाक्य' : 'Textbook Quote'}:
                      </span>
                      &ldquo;{msg.responseObj.quote}&rdquo;
                    </div>
                  )}

                  {/* Ghar Ki Boli Toggle Expansion */}
                  {showGharKiBoli && msg.responseObj.ghar_ki_boli && (
                    <div className="text-xs bg-amber-50 dark:bg-amber-950/40 p-2 rounded-lg border border-amber-200 dark:border-amber-900/60 text-amber-900 dark:text-amber-200">
                      <span className="font-bold text-[10px] text-amber-700 dark:text-amber-400 flex items-center space-x-1">
                        <Home className="w-3 h-3" />
                        <span>घर की बोली में समझें (गांव की सरल भाषा):</span>
                      </span>
                      <p className="mt-0.5">{msg.responseObj.ghar_ki_boli}</p>
                    </div>
                  )}

                  {/* Bilingual Side-by-Side English Translation */}
                  {showBilingual && msg.responseObj.bilingual_en && (
                    <div className="text-xs bg-blue-50 dark:bg-blue-950/40 p-2 rounded-lg border border-blue-200 dark:border-blue-900/60 text-blue-900 dark:text-blue-200">
                      <span className="font-bold text-[10px] text-blue-700 dark:text-blue-400 flex items-center space-x-1">
                        <Languages className="w-3 h-3" />
                        <span>English Explanation:</span>
                      </span>
                      <p className="mt-0.5">{msg.responseObj.bilingual_en}</p>
                    </div>
                  )}
                </div>
              )}

              {/* If Off-Chapter Refusal: Show Polite Refusal + Forward to Teacher Button */}
              {msg.responseObj && !msg.responseObj.in_chapter && (
                <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700 space-y-2">
                  <div className="flex items-center space-x-1.5 text-xs text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 p-2 rounded-lg border border-amber-200 dark:border-amber-900">
                    <AlertCircle className="w-4 h-4 shrink-0 text-amber-600" />
                    <span>
                      {uiLang === 'hi'
                        ? 'यह प्रश्न पाठ के बाहर का है।'
                        : 'This question is outside this textbook chapter.'}
                    </span>
                  </div>

                  {forwardSuccessId === msg.responseObj.doubtId ? (
                    <div className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center space-x-1 font-semibold p-1">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>
                        {uiLang === 'hi'
                          ? 'अध्यापिका के इनबॉक्स में भेज दिया गया है!'
                          : 'Forwarded to teacher\'s inbox successfully!'}
                      </span>
                    </div>
                  ) : (
                    <button
                      onClick={() => forwardToTeacher(msg.responseObj?.doubtId, msg.text)}
                      className="w-full flex items-center justify-center space-x-1.5 py-1.5 px-3 rounded-lg text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white shadow-sm transition"
                    >
                      <Inbox className="w-3.5 h-3.5" />
                      <span>
                        {uiLang === 'hi'
                          ? 'यह सवाल अपनी शिक्षिका को भेजें'
                          : 'Send to Teacher\'s "Questions For You" Inbox'}
                      </span>
                    </button>
                  )}
                </div>
              )}

              {/* Footer row: Timestamp & Read Aloud TTS button */}
              <div className="flex items-center justify-between mt-2 pt-1 text-[10px] text-slate-400">
                <span>{msg.timestamp}</span>
                {msg.sender === 'assistant' && (
                  <button
                    onClick={() => speakText(msg.text, msg.id)}
                    className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-300 transition"
                    title={speakingMsgId === msg.id ? 'Stop Voice' : 'Read Aloud'}
                  >
                    {speakingMsgId === msg.id ? (
                      <VolumeX className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
                    ) : (
                      <Volume2 className="w-3.5 h-3.5" />
                    )}
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex items-center space-x-2 text-slate-400 text-xs p-2">
            <Sparkles className="w-4 h-4 text-amber-500 animate-spin" />
            <span>
              {uiLang === 'hi'
                ? 'पाठ्यपुस्तक में उत्तर खोजा जा रहा है...'
                : 'Searching textbook section and verifying citations...'}
            </span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Suggestion Chips */}
      <div className="my-3">
        <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1.5 block">
          {uiLang === 'hi' ? 'जल्दी पूछें (उदाहरण सवाल):' : 'Quick doubts to test:'}
        </span>
        <div className="flex flex-wrap gap-1.5">
          {starterDoubtChips.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(chip.label)}
              className="text-xs px-2.5 py-1 rounded-full border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/80 hover:border-amber-400 dark:hover:border-amber-600 text-slate-700 dark:text-slate-300 shadow-2xs transition"
            >
              {chip.label}
            </button>
          ))}
        </div>
      </div>

      {/* Input Bar: Mic + Text Input + Send Button */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-2 border border-slate-300 dark:border-slate-800 shadow-md flex items-center space-x-2">
        {/* Voice Input Mic Button */}
        <button
          onClick={toggleVoiceInput}
          className={`p-2.5 rounded-xl transition ${
            isListening
              ? 'bg-red-600 text-white animate-pulse shadow-md shadow-red-500/30'
              : 'bg-amber-100 hover:bg-amber-200 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
          }`}
          title={isListening ? 'Listening (Click to stop)...' : 'Speak doubt in Hindi / Hinglish'}
        >
          {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        {/* Input Text Box */}
        <input
          type="text"
          value={inputQuestion}
          onChange={e => setInputQuestion(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder={
            isListening
              ? 'सुन रहे हैं... बोलिए (Listening in Hindi/Hinglish)...'
              : uiLang === 'hi'
              ? 'अपना सवाल लिखें या माइक दबाकर बोलें...'
              : 'Type doubt or click mic to speak (Hindi/Hinglish/EN)...'
          }
          className="flex-1 bg-transparent text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none px-2"
        />

        {/* Send Button */}
        <button
          onClick={() => handleSend()}
          disabled={!inputQuestion.trim() || loading}
          className="p-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white shadow-md shadow-amber-600/20 transition"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>

      <p className="text-[10px] text-center text-slate-400 mt-2">
        बिहार सरकार • शिक्षा विभाग | Gurukul AI is strictly grounded in NCERT textbook chapters.
      </p>

    </div>
  );
};
