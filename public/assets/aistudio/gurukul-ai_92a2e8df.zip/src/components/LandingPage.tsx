import React, { useState } from 'react';
import {
  GraduationCap,
  Sparkles,
  BookOpen,
  User,
  ShieldCheck,
  CheckCircle2,
  HelpCircle,
  ChevronDown,
  ArrowRight,
  Mic,
  Clock,
  Share2,
  FileCheck2,
  Smartphone,
  Cpu,
  Layers,
  Heart
} from 'lucide-react';
import { Role, UILanguage } from '../types';

interface LandingPageProps {
  onSelectRole: (role: Role) => void;
  uiLang: UILanguage;
  onOpenTests: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onSelectRole,
  uiLang,
  onOpenTests,
}) => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: 'Does it work in Hindi? (क्या यह हिंदी में काम करता है?)',
      a: 'हाँ, गुरुकुल AI पूरी तरह हिंदी (देवनागरी), हिंग्लिश और अंग्रेजी तीनों में काम करता है। छात्र हिंदी में माइक दबाकर बोल सकते हैं और सरल देवनागरी में उत्तर सुन सकते हैं। इसके अलावा ग्रामीण बच्चों के लिए "घर की बोली" (Village Hindi) का विकल्प भी उपलब्ध है।',
    },
    {
      q: 'Will it make up answers or hallucinate? (क्या यह गलत उत्तर बना सकता है?)',
      a: 'बिलकुल नहीं! गुरुकुल AI किसी बाहरी इंटरनेट ज्ञान का उपयोग नहीं करता। यह शत-प्रतिशत केवल आपके पाठ्यपुस्तक अध्याय से उत्तर देता है और हर उत्तर के साथ अध्याय का अनुभाग संख्या एवं मूल वाक्य उद्धृत करता है। यदि प्रश्न पाठ में नहीं है, तो विनम्रतापूर्वक मना कर शिक्षक इनबॉक्स में भेज देता है।',
    },
    {
      q: 'Which classes and subjects does it support? (यह किन कक्षाओं और विषयों के लिए है?)',
      a: 'वर्तमान में यह बिहार राज्य पाठ्यचर्या (SCERT/NCERT) के कक्षा 6, 7 और 8 के विज्ञान एवं पर्यावरण अध्ययन के लिए सुसज्जित है। शिक्षक किसी भी नए विषय या अध्याय का टेक्स्ट या फोटो अपलोड करके इसे तुरंत उपयोग में ला सकते हैं।',
    },
    {
      q: 'Do teachers need technical training? (क्या शिक्षकों को विशेष तकनीकी प्रशिक्षण चाहिए?)',
      a: 'नहीं! केवल 1 क्लिक में अपनी घंटी की अवधि (30, 40 या 45 मिनट) चुनें और पाठ योजना तैयार हो जाती है। इसे सीधे WhatsApp पर साझा किया जा सकता है या एक क्लिक में प्रिंट किया जा सकता है।',
    },
    {
      q: 'Does it work on a cheap Android phone? (क्या यह सस्ते 4G/3G फोन पर चलेगा?)',
      a: 'हाँ! इसे बिहार के ग्रामीण क्षेत्रों के सस्ते स्मार्टफोन को ध्यान में रखकर हल्का PWA (प्रोग्रेसिव वेब ऐप) बनाया गया है। अंतिम पाठ योजना और क्विज ऑफलाइन भी खुलते हैं।',
    },
    {
      q: 'Do we have to build a whole LMS? (क्या हमें पूरा एलएमएस सिस्टम बनाना पड़ेगा?)',
      a: 'बिल्कुल नहीं! कोई भारी यूजरनेम या पासवर्ड नहीं चाहिए। छात्र केवल अपने कक्षा कोड (जैसे BIHAR7A) और रोल नंबर से सीधे प्रवेश कर सकते हैं।',
    },
    {
      q: 'Can we use a different chapter or upload our own? (क्या हम दूसरा पाठ इस्तेमाल कर सकते हैं?)',
      a: 'हाँ! गुरुकुल AI किसी भी एक पाठ के लिए हार्ड-कोडेड नहीं है। आप जल चक्र, अम्ल-क्षार या किसी भी पाठ्यपुस्तक के पृष्ठ की फोटो खींचकर या टेक्स्ट पेस्ट करके तुरंत नया अध्याय जोड़ सकते हैं।',
    },
  ];

  return (
    <div className="space-y-16 pb-16">
      
      {/* HERO SECTION */}
      <section className="relative overflow-hidden pt-12 pb-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-amber-50/60 via-orange-50/30 to-white dark:from-slate-900 dark:via-slate-900/90 dark:to-slate-950">
        <div className="max-w-5xl mx-auto text-center space-y-6">
          
          {/* Badge */}
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-amber-100 text-amber-900 dark:bg-amber-950/80 dark:text-amber-300 border border-amber-300 dark:border-amber-800 text-xs font-bold shadow-2xs">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <span>Build#thon 2026 • Idea A: AI For Bihar Government Schools</span>
          </div>

          {/* Hero Line */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 dark:text-white tracking-tight leading-tight">
            Gurukul AI: every child&apos;s doubt answered,{' '}
            <span className="bg-gradient-to-r from-amber-600 via-orange-500 to-amber-700 bg-clip-text text-transparent">
              every teacher&apos;s evening saved
            </span>
          </h1>

          {/* Subtitle */}
          <p className="max-w-3xl mx-auto text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed font-medium">
            बिहार के 70,000+ सरकारी विद्यालयों के लिए समर्पित। शत-प्रतिशत पाठ्यपुस्तक पर आधारित: शिक्षकों के लिए सटीक समयबद्ध पाठ योजना व क्विज, छात्रों के लिए हिंदी व घर की बोली में संशय निवारण।
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => onSelectRole('student')}
              className="flex items-center space-x-2 px-6 py-3.5 rounded-2xl font-bold text-sm bg-gradient-to-r from-amber-600 to-orange-500 hover:from-amber-700 hover:to-orange-600 text-white shadow-lg shadow-amber-500/25 transition transform hover:-translate-y-0.5"
            >
              <Mic className="w-4 h-4" />
              <span>Ask a Doubt (विद्यार्थी चैट)</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onSelectRole('teacher')}
              className="flex items-center space-x-2 px-6 py-3.5 rounded-2xl font-bold text-sm bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 border border-slate-300 dark:border-slate-700 shadow-sm transition"
            >
              <BookOpen className="w-4 h-4 text-amber-600" />
              <span>Teacher Portal (पाठ योजना व डैशबोर्ड)</span>
            </button>

            <button
              onClick={onOpenTests}
              className="flex items-center space-x-1.5 px-4 py-3.5 rounded-2xl font-bold text-xs bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 hover:bg-emerald-100 transition"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Run 5/5 Acceptance Tests</span>
            </button>
          </div>

          {/* Quick Metrics Bar */}
          <div className="pt-6 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-3xl mx-auto text-left text-xs">
            <div className="p-3 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-2xs">
              <span className="font-extrabold text-amber-600 block text-base font-mono">100%</span>
              <span className="text-slate-600 dark:text-slate-400">Grounded Citations (No Hallucinations)</span>
            </div>
            <div className="p-3 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-2xs">
              <span className="font-extrabold text-emerald-600 block text-base font-mono">30 / 40 / 45m</span>
              <span className="text-slate-600 dark:text-slate-400">Exact Timed Lesson Plans</span>
            </div>
            <div className="p-3 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-2xs">
              <span className="font-extrabold text-orange-600 block text-base font-mono">hi-IN Speech</span>
              <span className="text-slate-600 dark:text-slate-400">Hindi Voice & Ghar Ki Boli</span>
            </div>
            <div className="p-3 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 shadow-2xs">
              <span className="font-extrabold text-blue-600 block text-base font-mono">Paper-to-Data</span>
              <span className="text-slate-600 dark:text-slate-400">Gemini Vision Answer Sheet OCR</span>
            </div>
          </div>

        </div>
      </section>

      {/* 3-STEP "HOW IT WORKS" SECTION */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-2 mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
            सिद्धांत से कक्षा तक
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            How It Works in 3 Simple Steps
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 max-w-xl mx-auto">
            Zero configuration required. Designed for government school teachers with zero free periods.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Step 1 */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 relative">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-extrabold flex items-center justify-center font-mono">
              01
            </div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Grounded on State Curriculum
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Select or photograph any NCERT/SCERT textbook chapter. The regex engine breaks the text into numbered sections with citation verification.
            </p>
          </div>

          {/* Step 2 */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 relative">
            <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300 font-extrabold flex items-center justify-center font-mono">
              02
            </div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Timed Plan & 100% Verified Quiz
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Teachers get a lesson plan whose minutes add up exactly to the period (30/40/45 min) plus a 5-MCQ quiz where every answer key is server-validated against textbook evidence.
            </p>
          </div>

          {/* Step 3 */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 relative">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-extrabold flex items-center justify-center font-mono">
              03
            </div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Doubt-to-Dashboard Mastery Loop
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Students ask doubts by voice in Hindi or Hinglish. Every doubt links back to its section, pinpointing classroom weak topics (e.g. &ldquo;12 doubts on Stomata today&rdquo;).
            </p>
          </div>

        </div>
      </section>

      {/* CORE FEATURES SECTION */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-2 mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
            विशिष्टताएं (Features)
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Built for the Realities of Bihar Classrooms
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
            <Mic className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">Hindi & Hinglish Speech</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Web Speech API recognition in <code>hi-IN</code> so students can ask doubts naturally without typing hurdles.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
            <FileCheck2 className="w-5 h-5 text-emerald-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">Zero-Hallucination Citations</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              The server validates that every answer quote is a verbatim substring of the chapter section before sending.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
            <Share2 className="w-5 h-5 text-green-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">1-Click WhatsApp Parent Reports</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Simple Hindi progress cards sent directly to parents on WhatsApp after teacher approval.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
            <Cpu className="w-5 h-5 text-orange-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">Paper-to-Data Vision OCR</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Photograph physical student answer sheets; Gemini Vision extracts answers into quiz results with an interactive verification table.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
            <Layers className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">Auto-Tiered Remedial Groups</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Auto-splits the class into Needs Help / On Track / Ready to Stretch with 10-minute micro-activities for each group.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
            <Smartphone className="w-5 h-5 text-teal-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">Offline PWA on Cheap Phones</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Large tap targets, fast caching, and offline access to the last generated lesson plan and quiz.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ SECTION (ALL 7 QUESTIONS) */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-2 mb-8">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
            प्रश्नोत्तरी (FAQ)
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                className="border border-slate-200 dark:border-slate-800 rounded-2xl bg-white dark:bg-slate-900 overflow-hidden shadow-2xs"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full p-4 text-left flex items-center justify-between font-bold text-sm text-slate-900 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/40 transition"
                >
                  <span>{faq.q}</span>
                  <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180 text-amber-600' : ''}`} />
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-800 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* TEAM & MISSION SECTION */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
        <div className="p-8 rounded-3xl bg-gradient-to-br from-amber-500/10 via-orange-500/10 to-amber-700/10 border border-amber-200 dark:border-amber-900/60 shadow-sm space-y-3">
          <Heart className="w-8 h-8 text-red-500 mx-auto" />
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
            Our Mission: Empowering Every Shikshak &amp; Vidyarthi in Bihar
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Gurukul AI was built for Build#thon 2026 to solve the foundational dual dilemma of Indian government schooling: rural students hesitate to ask doubts due to shyness, while dedicated government school teachers spend their entire evenings preparing multi-grade lesson plans by candlelight or dim bulbs. Gurukul AI answers every doubt and saves every teacher&apos;s evening.
          </p>
          <div className="pt-2 text-xs font-semibold text-amber-800 dark:text-amber-300">
            Dedicated to Middle &amp; Secondary Government Schools across Patna, Gaya, Muzaffarpur, Bhagalpur and all 38 districts of Bihar.
          </div>
        </div>
      </section>

    </div>
  );
};
