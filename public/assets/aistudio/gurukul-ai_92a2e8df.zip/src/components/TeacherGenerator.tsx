import React, { useState } from 'react';
import {
  Sparkles,
  BookOpen,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Copy,
  Printer,
  Share2,
  Upload,
  Camera,
  FileText,
  ListOrdered,
  Layers,
  HelpCircle,
  Check,
  ChevronDown,
  Info
} from 'lucide-react';
import { Chapter, LessonPlanOutput, UILanguage } from '../types';

interface TeacherGeneratorProps {
  chapters: Chapter[];
  selectedChapterId: string;
  onSelectChapter: (id: string) => void;
  uiLang: UILanguage;
  onChapterUploaded: () => void;
}

export const TeacherGenerator: React.FC<TeacherGeneratorProps> = ({
  chapters,
  selectedChapterId,
  onSelectChapter,
  uiLang,
  onChapterUploaded,
}) => {
  const [selectedClass, setSelectedClass] = useState('Class 7');
  const [selectedSubject, setSelectedSubject] = useState('Science');
  const [periodLength, setPeriodLength] = useState<number>(40);
  const [language, setLanguage] = useState<'Hindi' | 'English'>('Hindi');
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState<LessonPlanOutput | null>(null);
  const [copied, setCopied] = useState(false);

  // Upload own chapter state
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadContent, setUploadContent] = useState('');
  const [uploadingImage, setUploadingImage] = useState(false);
  const [uploadSuccessMsg, setUploadSuccessMsg] = useState('');

  const generatePlan = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/lesson-plan/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chapterId: selectedChapterId,
          className: selectedClass,
          subject: selectedSubject,
          periodLength,
          language,
        }),
      });
      const data = await res.json();
      if (data.success && data.plan) {
        setPlan(data.plan);
        // Cache to localStorage for offline PWA
        localStorage.setItem('gurukul_cached_lesson_plan', JSON.stringify(data.plan));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (!plan) return;
    const textToCopy = `GURUKUL AI - LESSON PLAN & QUIZ
Class: ${plan.class} | Subject: ${plan.subject}
Chapter: ${plan.chapter}
Duration: ${plan.period_length_minutes} Minutes | Language: ${plan.language}

OBJECTIVES:
${plan.objectives.map((o, i) => `${i + 1}. ${o}`).join('\n')}

MATERIALS:
${plan.materials_needed.join(', ')}

BOARD DIAGRAM:
${plan.board_diagram_description}

TIMED LESSON FLOW (Adds up to ${plan.period_length_minutes} mins):
${plan.timed_flow.map(s => `• [${s.duration_minutes}m] ${s.step} (${s.section_ref}): ${s.teacher_activity}`).join('\n')}

5-QUESTION VERIFIED QUIZ:
${plan.quiz_questions.map((q, idx) => `Q${idx + 1}: ${q.q}\nOptions: ${q.options.join(' | ')}\nAnswer: ${q.answer} [${q.section}]`).join('\n\n')}
`;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const printPlan = () => {
    window.print();
  };

  const shareOnWhatsApp = () => {
    if (!plan) return;
    const shareText = `*गुरुकुल AI पाठ योजना (${plan.period_length_minutes} मिनट)*\n*कक्षा:* ${plan.class} - ${plan.subject}\n*अध्याय:* ${plan.chapter}\n\n*उद्देश्य:*\n${plan.objectives.map((o, i) => `${i + 1}. ${o}`).join('\n')}\n\n*5-प्रश्न क्विज (सत्यापित उत्तर कुंजी):*\n${plan.quiz_questions.map((q, i) => `${i + 1}. ${q.q} -> *${q.answer}* (${q.section})`).join('\n')}\n\n- राजकीय मध्य विद्यालय, बिहार`;
    window.open(`https://wa.me/?text=${encodeURIComponent(shareText)}`, '_blank');
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingImage(true);
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        const res = await fetch('/api/chapters/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: uploadTitle || file.name.replace(/\.[^/.]+$/, ''),
            subject: selectedSubject,
            grade: selectedClass,
            language,
            imageBase64: base64,
            mimeType: file.type,
          }),
        });
        const data = await res.json();
        if (data.success) {
          setUploadSuccessMsg(`Chapter uploaded successfully! (${data.chapter.sectionsCount} sections parsed)`);
          onChapterUploaded();
          setTimeout(() => {
            setShowUploadModal(false);
            setUploadSuccessMsg('');
          }, 1500);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setUploadingImage(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleTextUpload = async () => {
    if (!uploadTitle.trim() || !uploadContent.trim()) return;
    setUploadingImage(true);
    try {
      const res = await fetch('/api/chapters/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: uploadTitle,
          content: uploadContent,
          subject: selectedSubject,
          grade: selectedClass,
          language,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setUploadSuccessMsg(`Chapter uploaded successfully! (${data.chapter.sectionsCount} sections parsed)`);
        onChapterUploaded();
        setTimeout(() => {
          setShowUploadModal(false);
          setUploadSuccessMsg('');
          setUploadTitle('');
          setUploadContent('');
        }, 1500);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setUploadingImage(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">
      
      {/* Configuration Card */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center space-x-2">
              <BookOpen className="w-5 h-5 text-amber-600" />
              <span>{uiLang === 'hi' ? 'शिक्षक जनरेटर: पाठ योजना एवं क्विज' : 'Teacher Generator: Lesson Plan & Quiz'}</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {uiLang === 'hi'
                ? 'कक्षा अवधि (30/40/45 मिनट) अनुसार सटीक समयबद्ध योजना व 100% सत्यापित 5-प्रश्न क्विज'
                : 'Timed lesson flow adding up strictly to period length + 5 MCQs with verified evidence.'}
            </p>
          </div>

          <button
            onClick={() => setShowUploadModal(true)}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-800 dark:text-amber-300 hover:bg-amber-100 transition shadow-2xs"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>{uiLang === 'hi' ? '+ अपना पाठ अपलोड करें' : '+ Upload Your Own Chapter'}</span>
          </button>
        </div>

        {/* Inputs Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mt-4 text-xs">
          
          {/* Class */}
          <div>
            <label className="font-semibold text-slate-700 dark:text-slate-300 mb-1 block">
              {uiLang === 'hi' ? 'कक्षा (Class)' : 'Class'}
            </label>
            <select
              value={selectedClass}
              onChange={e => setSelectedClass(e.target.value)}
              className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-medium"
            >
              <option value="Class 6">Class 6 (छठी)</option>
              <option value="Class 7">Class 7 (सातवीं)</option>
              <option value="Class 8">Class 8 (आठवीं)</option>
            </select>
          </div>

          {/* Subject */}
          <div>
            <label className="font-semibold text-slate-700 dark:text-slate-300 mb-1 block">
              {uiLang === 'hi' ? 'विषय (Subject)' : 'Subject'}
            </label>
            <select
              value={selectedSubject}
              onChange={e => setSelectedSubject(e.target.value)}
              className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-medium"
            >
              <option value="Science">विज्ञान (Science)</option>
              <option value="EVS">पर्यावरण अध्ययन (EVS)</option>
            </select>
          </div>

          {/* Chapter */}
          <div className="lg:col-span-1">
            <label className="font-semibold text-slate-700 dark:text-slate-300 mb-1 block">
              {uiLang === 'hi' ? 'अध्याय (Chapter)' : 'Chapter'}
            </label>
            <select
              value={selectedChapterId}
              onChange={e => onSelectChapter(e.target.value)}
              className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-medium truncate"
            >
              {chapters.map(ch => (
                <option key={ch.id} value={ch.id}>
                  {ch.title}
                </option>
              ))}
            </select>
          </div>

          {/* Period Length */}
          <div>
            <label className="font-semibold text-slate-700 dark:text-slate-300 mb-1 block">
              {uiLang === 'hi' ? 'घंटी की अवधि (Period)' : 'Period Length'}
            </label>
            <div className="grid grid-cols-3 gap-1">
              {[30, 40, 45].map(len => (
                <button
                  key={len}
                  type="button"
                  onClick={() => setPeriodLength(len)}
                  className={`py-2 rounded-lg font-bold transition text-xs ${
                    periodLength === len
                      ? 'bg-amber-600 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {len}m
                </button>
              ))}
            </div>
          </div>

          {/* Language */}
          <div>
            <label className="font-semibold text-slate-700 dark:text-slate-300 mb-1 block">
              {uiLang === 'hi' ? 'भाषा (Language)' : 'Output Language'}
            </label>
            <div className="grid grid-cols-2 gap-1">
              {(['Hindi', 'English'] as const).map(lng => (
                <button
                  key={lng}
                  type="button"
                  onClick={() => setLanguage(lng)}
                  className={`py-2 rounded-lg font-bold transition text-xs ${
                    language === lng
                      ? 'bg-amber-600 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {lng === 'Hindi' ? 'हिंदी' : 'English'}
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Generate Button */}
        <div className="mt-5 flex justify-end">
          <button
            onClick={generatePlan}
            disabled={loading}
            className="flex items-center space-x-2 px-5 py-2.5 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-600 to-orange-500 hover:from-amber-700 hover:to-orange-600 disabled:opacity-50 text-white shadow-md shadow-amber-500/20 transition"
          >
            <Sparkles className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>
              {loading
                ? uiLang === 'hi'
                  ? 'पाठ योजना तैयार हो रही है...'
                  : 'Generating & Verifying Citations...'
                : uiLang === 'hi'
                ? 'पाठ योजना व क्विज बनाएं'
                : 'Generate Lesson Plan & 5-MCQ Quiz'}
            </span>
          </button>
        </div>
      </div>

      {/* Generated Lesson Plan Card */}
      {plan && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden printable-area">
          
          {/* Card Header & Actions */}
          <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-base font-extrabold text-slate-900 dark:text-white">
                  {plan.class} {plan.subject}: {plan.chapter}
                </span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-bold">
                  {plan.period_length_minutes} Min Plan
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Language: {plan.language} • Verified against textbook sections
              </p>
            </div>

            {/* Actions: Copy, Print, WhatsApp */}
            <div className="flex items-center space-x-2 no-print">
              <button
                onClick={copyToClipboard}
                className="flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 text-slate-700 dark:text-slate-200 transition shadow-2xs"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy'}</span>
              </button>

              <button
                onClick={printPlan}
                className="flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 text-slate-700 dark:text-slate-200 transition shadow-2xs"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print</span>
              </button>

              <button
                onClick={shareOnWhatsApp}
                className="flex items-center space-x-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition shadow-sm"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </button>
            </div>
          </div>

          <div className="p-6 space-y-6">
            
            {/* Objectives & Materials */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Objectives */}
              <div className="p-4 rounded-xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/50 dark:border-amber-900/40">
                <h3 className="text-xs font-bold text-amber-900 dark:text-amber-200 uppercase tracking-wider mb-2 flex items-center space-x-1.5">
                  <CheckCircle2 className="w-4 h-4 text-amber-600" />
                  <span>{uiLang === 'hi' ? 'शिक्षण उद्देश्य (Learning Objectives)' : 'Learning Objectives'}</span>
                </h3>
                <ul className="text-xs space-y-1.5 text-slate-700 dark:text-slate-300">
                  {plan.objectives.map((obj, i) => (
                    <li key={i} className="flex items-start space-x-2">
                      <span className="font-bold text-amber-600">{i + 1}.</span>
                      <span>{obj}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Materials */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
                <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider mb-2 flex items-center space-x-1.5">
                  <Layers className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                  <span>{uiLang === 'hi' ? 'आवश्यक सामग्री (Low-Cost Teaching Aids)' : 'Materials Needed'}</span>
                </h3>
                <div className="flex flex-wrap gap-1.5 text-xs">
                  {plan.materials_needed.map((mat, i) => (
                    <span
                      key={i}
                      className="px-2 py-1 rounded-md bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"
                    >
                      {mat}
                    </span>
                  ))}
                </div>
              </div>

            </div>

            {/* Board Diagram Description */}
            <div className="p-4 rounded-xl bg-orange-50/40 dark:bg-orange-950/20 border border-orange-200/60 dark:border-orange-900/40 text-xs">
              <h3 className="font-bold text-orange-900 dark:text-orange-200 uppercase tracking-wider mb-1 flex items-center space-x-1.5">
                <FileText className="w-4 h-4 text-orange-600" />
                <span>{uiLang === 'hi' ? 'श्यामपट्ट (Blackboard) चित्र निर्देश' : 'Blackboard Visual Diagram Description'}</span>
              </h3>
              <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                {plan.board_diagram_description}
              </p>
            </div>

            {/* Timed Lesson Flow */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-amber-600" />
                  <span>{uiLang === 'hi' ? 'समयबद्ध कक्षा प्रवाह (Timed Flow)' : 'Timed Period Flow'}</span>
                </h3>
                <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800">
                  Total: {plan.timed_flow.reduce((sum, item) => sum + (Number(item.duration_minutes) || 0), 0)} / {plan.period_length_minutes} Minutes Exact Match
                </span>
              </div>

              <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                {plan.timed_flow.map((step, idx) => (
                  <div key={idx} className="p-3.5 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                    <div className="flex items-center justify-between font-semibold text-slate-900 dark:text-white mb-1.5">
                      <div className="flex items-center space-x-2">
                        <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 flex items-center justify-center font-bold text-[11px]">
                          {idx + 1}
                        </span>
                        <span className="font-bold text-sm">{step.step}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                          {step.section_ref}
                        </span>
                      </div>
                      <span className="font-mono font-bold px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-900">
                        {step.duration_minutes} min
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2 pl-8 text-slate-600 dark:text-slate-300">
                      <div>
                        <span className="font-bold text-slate-500 dark:text-slate-400 block text-[10px] uppercase">
                          Teacher Activity:
                        </span>
                        <p>{step.teacher_activity}</p>
                      </div>
                      <div>
                        <span className="font-bold text-slate-500 dark:text-slate-400 block text-[10px] uppercase">
                          Student Activity:
                        </span>
                        <p>{step.student_activity}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 5-Question Quiz with Answer Key */}
            <div className="pt-2">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center space-x-2">
                    <ListOrdered className="w-4 h-4 text-amber-600" />
                    <span>{uiLang === 'hi' ? '5-प्रश्न वस्तुनिष्ठ क्विज एवं उत्तर कुंजी' : '5-Question Rapid Quiz & Verified Answer Key'}</span>
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Never show unverified answer keys: every question is server-validated against textbook section evidence.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {plan.quiz_questions.map((q, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 text-xs space-y-2.5"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-2">
                        <span className="font-extrabold text-amber-600 text-sm">
                          Q{idx + 1}.
                        </span>
                        <span className="font-bold text-slate-900 dark:text-slate-100 text-sm">
                          {q.q}
                        </span>
                      </div>

                      {/* Verification Badge */}
                      {q.verified ? (
                        <span className="flex items-center space-x-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 shrink-0">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>100% Verified</span>
                        </span>
                      ) : (
                        <span className="flex items-center space-x-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-300 shrink-0">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                          <span>Teacher Please Check</span>
                        </span>
                      )}
                    </div>

                    {/* 4 Options Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pl-6">
                      {q.options.map((opt, optIdx) => {
                        const isCorrect = opt === q.answer;
                        return (
                          <div
                            key={optIdx}
                            className={`p-2 rounded-lg border text-xs font-medium ${
                              isCorrect
                                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 font-bold'
                                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                            }`}
                          >
                            <span className="font-bold mr-1.5">{String.fromCharCode(65 + optIdx)}.</span>
                            {opt}
                            {isCorrect && (
                              <span className="ml-2 text-[10px] text-emerald-700 dark:text-emerald-400 uppercase font-mono">
                                (Answer Key)
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Verbatim Section Evidence Quote */}
                    <div className="pl-6 pt-1 text-[11px] text-slate-600 dark:text-slate-400 bg-white dark:bg-slate-900/60 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800">
                      <span className="font-bold text-slate-700 dark:text-slate-300 mr-1">
                        [{q.section}] Verified Evidence:
                      </span>
                      &ldquo;{q.evidence}&rdquo;
                    </div>

                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Upload Own Chapter Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl p-6 space-y-4">
            
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center space-x-2">
                <Upload className="w-5 h-5 text-amber-600" />
                <span>{uiLang === 'hi' ? 'नया अध्याय अपलोड करें' : 'Upload Chapter (Text or Photo)'}</span>
              </h3>
              <button
                onClick={() => setShowUploadModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400">
              Paste your chapter text with numbered sections (e.g. &ldquo;Section 1: ...&rdquo;) or upload a photo of the textbook page. Gemini Vision OCR will parse it into numbered sections.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 mb-1 block">
                  Chapter Title
                </label>
                <input
                  type="text"
                  value={uploadTitle}
                  onChange={e => setUploadTitle(e.target.value)}
                  placeholder="e.g. Class 7 Science: Acids, Bases and Salts"
                  className="w-full py-2 px-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                />
              </div>

              {/* Photo Upload Option */}
              <div className="p-3 rounded-xl border border-dashed border-amber-300 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-950/20 text-center">
                <Camera className="w-6 h-6 text-amber-600 mx-auto mb-1" />
                <span className="font-bold text-amber-900 dark:text-amber-200 block text-xs">
                  Take / Upload Photo of Textbook Page
                </span>
                <span className="text-[10px] text-slate-500 block mb-2">
                  Gemini 3.8 Flash Vision OCR extracts text into sections
                </span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  disabled={uploadingImage}
                  className="text-xs text-slate-500 file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-amber-600 file:text-white hover:file:bg-amber-700 cursor-pointer"
                />
              </div>

              <div className="text-center font-bold text-slate-400 text-[10px] uppercase">
                — OR PASTE TEXT DIRECTLY —
              </div>

              {/* Text Paste Option */}
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 mb-1 block">
                  Chapter Content (with Section 1:, Section 2: headings)
                </label>
                <textarea
                  rows={5}
                  value={uploadContent}
                  onChange={e => setUploadContent(e.target.value)}
                  placeholder="Section 1: Introduction...&#10;Section 2: Key Concepts..."
                  className="w-full py-2 px-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs"
                />
              </div>
            </div>

            {uploadSuccessMsg && (
              <div className="p-2 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-bold flex items-center space-x-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>{uploadSuccessMsg}</span>
              </div>
            )}

            <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setShowUploadModal(false)}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleTextUpload}
                disabled={uploadingImage || !uploadContent.trim()}
                className="px-4 py-1.5 text-xs font-bold rounded-lg bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white shadow-sm transition"
              >
                {uploadingImage ? 'Processing OCR...' : 'Save Chapter'}
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
