# Builder guide — `A-gurukul-ai`

## 3-hour MVP path

1. Load chapter_photosynthesis_hi.txt (or _en) into the LLM system prompt: answer only from this text and cite the section.
2. Build teacher flow: prompt → JSON lesson plan matching lesson_plan_format.json + 5-question quiz with answer key.
3. Build student chat: refuse off-topic questions (e.g. cricket) with a polite message.
4. Use pandas on quiz_results.csv grouped by topic to show the weakest topic for class7A_roster.csv.
5. Ship a simple Hindi/English UI with both teacher and student modes.

## Starter files — how to use them

- **chapter_photosynthesis_en.txt** — English Class 7 chapter text — put the whole file in the prompt (small enough; RAG optional).
- **chapter_photosynthesis_hi.txt** — Same chapter in Hindi — use for Hindi answers and quizzes.
- **chapter_water_cycle_en.txt** — Second chapter to prove the tool is not hard-coded to photosynthesis.
- **class7A_roster.csv** — 30 fictional students — join with quiz results for the class dashboard.
- **quiz_results.csv** — 240 topic-wise scores — groupby topic, find mean < 40% as weak topics.
- **lesson_plan_format.json** — Target JSON shape for lesson plans so the UI can render timed sections.
