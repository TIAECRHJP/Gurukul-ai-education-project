# Gurukul AI
**build#thon 2026 · Problem Statement · Idea A**  
*An AI classroom assistant for government schools*

> **Why the name:** Gurukul: India's ancient school, where every student got the guru's full attention. Now every child can, with AI.

**Tags:** `Education` · `Schools` · `Teachers` · `Hindi` · `RAG` · `Quiz generation`

---

## 1. The problem
A government school teacher in Bihar often handles 50 or more students across several subjects, with little time to plan lessons, make quizzes or find out which child is falling behind. Students who don't understand a topic in class have nobody to ask at home, and most digital learning content is in English, made for city schools, and not tied to the textbook they actually study.

### Why it matters
- Teachers spend hours on lesson plans, question papers and checking, time that could go to teaching.
- Weak students are noticed too late, usually only after the exam.
- A student's doubt at 8 PM has no answer until the next class, if the student asks at all.
- States are looking for affordable, local-language digital classrooms, so this can become a real product pitched to state education departments.

### Who it's for
Government primary and secondary schools: teachers, students, and later the state education department

## 2. Your goal
Build an assistant that works from the school's own chapter text. For the teacher, it generates a lesson plan and a quiz for a chapter, and shows which topics the class is weak in. For the student, it answers doubts in Hindi or English using only the chapter, and says so when a question is outside it.

### Case studies (use these in your demo)
1. Teacher Sunita says in Hindi: "Kal ke liye photosynthesis ka 40 minute ka lesson plan banao." She gets a timed plan, a board diagram description and a 5-question quiz, each linked to a chapter section.
2. Student Khushi asks at night: "stomata kya hota hai?" She gets a 2-line Hinglish answer that quotes the chapter section.
3. The dashboard shows that 9 of 30 students are below 40% on Saprotrophs and suggests a 10-minute revision with three practice questions.

### Expected behaviour (example)
- **Input:** Teacher (Hindi voice): "Class 7 ke liye photosynthesis par 5 sawal ka quiz banao"
- **Output:** 5 Hindi MCQs, each with options, the correct answer and the chapter section it came from. Example: "प्रकाश संश्लेषण में पौधे कौन सी गैस लेते हैं? A) ऑक्सीजन B) कार्बन डाइऑक्साइड ✓ (खंड 2)"

![Expected behaviour (illustrative)](expected-behaviour.png)
*Illustrative mockup. Your design can be different.*

## 3. What you must build
### Must-have features (build these first, end to end)
1. Load at least one chapter (the starter chapters are provided) and answer student questions **grounded in the chapter**, showing the section used as the source.
2. Generate a lesson plan for a chosen chapter, class and period length, following the sample JSON format or your own.
3. Generate a 5-question multiple-choice quiz with answers, in Hindi or English.
4. A teacher view that reads quiz_results.csv and shows topic-wise class performance and the weakest topic, with a suggestion.
5. Refuse or redirect questions outside the chapter ("Ask your teacher") instead of inventing answers.

### Screens to build
1. **Landing page** (see the common spec): hero "Gurukul AI: every child's doubt answered, every teacher's evening saved", how it works in 3 steps, features, FAQ, team.
2. **Teacher: Lesson & quiz generator**: pick class, subject, chapter, period length and language → lesson plan card + 5-question quiz with answers and chapter-section sources; copy or print buttons.
3. **Student: Ask a doubt**: chat box (type or mic), answer in Hindi or English with the source section shown; an "Ask your teacher" reply for off-chapter questions.
4. **Teacher dashboard**: topic-wise class mastery bars from quiz_results.csv, the weakest topic highlighted, the AI suggestion card, a list of students who need help.

### Stretch goals (only after the must-haves work)
- Voice input (Hindi) for teacher and student
- Read answers aloud
- Per-student report for parents in simple Hindi
- Works on a cheap Android phone screen
- Bilingual output (Hindi + English side by side)

## 4. Acceptance criteria: you're done when…
- [ ] A question from the chapter gets a correct answer that names the section it came from.
- [ ] An off-topic question ("Who won the cricket match?") is politely refused.
- [ ] A lesson plan and a 5-question Hindi quiz are generated for the photosynthesis chapter, and every answer key is correct.
- [ ] The dashboard shows the correct weakest topic from quiz_results.csv (check it with a quick pandas groupby).

## 5. What every submission must include
- A **working prototype** that runs live on your laptop (localhost is fine; no deployment needed).
- **AI doing real work** in the main flow, which you can explain to the jury.
- The **screens** listed above, clean and usable, in Hindi or Hinglish where the idea needs it.
- A one-page **landing page** for your product (checklist below), with at least 5 FAQs.
- This repository's code on **your branch, named exactly after your registration number** (for example `KBT-TM2-AB2CD3`), pushed before time-up.
- An updated **README** in your branch: product name, what it does, how to run it, tech and AI used, team and who did what.
- Up to **8 slides** and a rehearsed **5-minute live demo** (then 3 minutes of jury questions).
- The **safety and data rules** below, visible in the app.

### Landing page checklist
1. **Hero:** product name, a one-line promise, a short subtitle, and a big **Try the demo** button that opens your app.
2. **The problem:** 2–3 lines or 3 quick stats (you may use numbers from your problem statement; don't invent statistics).
3. **How it works:** 3 steps with icons (for example Scan → Verify → Act).
4. **Features:** 3–6 cards for what your prototype actually does (only features that work).
5. **Who it's for:** the users and the paying customer.
6. **FAQ:** at least 5 questions and answers (suggested questions are given in each idea), including one on safety or privacy.
7. **Team:** names and roles, and a footer: "Built at build#thon 2026 by Kiba Labs · Problem statement: Idea X".
8. Mobile-friendly, readable in Hindi where your users need it, fast to load. A single page is enough.

**Suggested FAQs for your landing page:** Does it work in Hindi? · Will it make up answers? · Which classes and subjects does it support? · Do teachers need training to use it? · Does it work on a cheap phone?

## 6. Starter data
All files are in the main folder of this repository:
- chapter_photosynthesis_en.txt and chapter_photosynthesis_hi.txt: a sample Class 7 chapter in English and Hindi
- chapter_water_cycle_en.txt: a sample Class 6 chapter
- class7A_roster.csv: 30 fictional students
- quiz_results.csv: 240 rows of topic-wise quiz scores
- lesson_plan_format.json: a suggested output structure

All starter data is synthetic or written for build#thon 2026. There are no real people's records, and it isn't official data.

### Public sources you may also use
- NCERT textbooks (free PDFs): ncert.nic.in/textbook.php. Fine for testing; don't redistribute
- DIKSHA (national school content platform): diksha.gov.in
- Bihar school textbooks: published by the Bihar State Textbook Publishing Corporation (BSTPC)

## 7. Suggested approach
1. Load the chapter text. It is small, so **long-context prompting** (put the whole chapter in the prompt) is enough; a vector database is optional.
2. Write a system prompt: answer only from the chapter, cite the section number, say "not in this chapter" otherwise.
3. Ask the LLM to return lesson plans and quizzes as JSON so you can render them nicely.
4. Use pandas to group quiz_results.csv by topic and find the weak topics, then let the LLM write the teacher-friendly suggestion.
5. Build the UI in Streamlit, Gradio, React or plain HTML, with two tabs: Teacher and Student.

### A realistic 3-hour plan
| Time | Focus |
|---|---|
| 0:00–0:20 | Read the data, choose the stack, set up the repo and branch, and test one LLM call. |
| 0:20–1:15 | Grounded Q&A with sources, plus the out-of-chapter refusal. |
| 1:15–2:00 | Lesson plan and quiz generator (JSON → UI). |
| 2:00–2:30 | Teacher dashboard from quiz_results.csv. |
| 2:30–3:00 | Hindi polish, demo script, slides, final commit. |

## 8. Known challenges and how to handle them
| Challenge | What to do |
|---|---|
| The AI makes up facts that aren't in the chapter. | Tell it to answer only from the provided text and to quote the section. Test it with an off-topic question such as "Who won the cricket match?" |
| Hindi output has spelling mistakes or mixes scripts. | Ask for "simple Hindi in Devanagari" explicitly. Keep a small set of example answers in the prompt. |
| Is this doable in 3 hours? | Yes. Each feature is a single LLM call over a small text plus a simple pandas summary. Don't build login, a database or a full LMS. |
| PDF chapters are hard to read. | Use the provided .txt chapters. If you use an NCERT PDF, copy the text out, or let a multimodal model read the page image. |

## 9. Rules
### For this idea
- Use the sample or public chapters only. No real student data.
- Answers must show where they came from.
- Keep it child-safe: no off-topic chat.

### For every team
- Build during the event; no project code written before it. Open-source libraries and AI coding tools are allowed.
- Never use real people's personal, medical, financial or land data.
- Let your code do the maths (totals, scores, dates); the AI explains the results.
- Show where answers come from; say "I don't know" instead of guessing.
- No screen sharing or calls during the build. Giving anyone remote access to your laptop means automatic rejection.
- Push every 20–30 minutes. Commits after time-up are rejected (exceptions only in special circumstances, at Kiba Labs' discretion).
- Everything built at build#thon 2026 belongs to Kiba Labs under the Terms. Don't make this code public.

## 10. How you'll be judged
| Criterion | Weight |
|---|---|
| Problem understanding | 20% |
| Innovation | 20% |
| Technical execution | 25% |
| Impact & feasibility | 20% |
| Demo & pitch | 15% |

Ties are broken by technical execution, then impact. The jury's decision is final.

**What the jury will look at for this idea:**
- Grounding: no invented facts, sources shown
- Usefulness to a real teacher (time saved)
- Quality of the generated Hindi
- Clear dashboard insight

A clean UI and an attractive landing page strengthen your demo & pitch and impact scores.

## 11. FAQ
**Q: Do we have to build the whole LMS?**  
No. Build the AI assistant core: Q&A, lesson plan, quiz and weak-topic insight. A full LMS comes later.

**Q: Can we use a different chapter?**  
Yes, any school chapter. The starter chapters are there so you don't lose time.

**Q: Must it be in Hindi?**  
At least one flow (answer or quiz) must work in Hindi. Everything else can be English.

## 12. Where this can go
A state-level AI classroom platform for government schools: content in the state's own textbooks and languages, teacher dashboards and district analytics.

---
*build#thon 2026 by Kiba Labs · Questions during the event: ask any mentor.*
